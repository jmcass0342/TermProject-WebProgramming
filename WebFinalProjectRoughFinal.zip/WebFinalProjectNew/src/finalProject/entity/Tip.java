package finalProject.entity;

public class Tip {
	private int id;
	private String tip;
	
	public Tip()
	{
		this.id = -1;
		this.tip = "";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}
	
	
	
}
