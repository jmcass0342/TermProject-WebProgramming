INSERT INTO exercises 
VALUES (3000,'Deadlift','https://www.youtube.com/watch?v=d5eGGZXb0Is',1);

INSERT INTO exercises 
VALUES (3001,'Hinge & Reach','https://www.youtube.com/watch?v=cZIqOYMQty4',1);

INSERT INTO exercises 
VALUES (3002,'DB Standing Press','https://www.youtube.com/watch?v=u9ziflQn3pE&index=18&list=PLvbOI6Hd_YM45VXCQ8hx0-AEUiwqIlSZD',2);

INSERT INTO exercises 
VALUES (3003,'Rotational Med Ball Throw','https://youtu.be/dWm_IdmpTLw?list=PLvbOI6Hd_YM76xJgBzQAWx0Rrx2C4nTta',2);

INSERT INTO exercises 
VALUES (3004,'TRX Row','https://youtu.be/x0L6iuTkaRI',2);

INSERT INTO exercises 
VALUES (3005,'Slideboard Crunch','https://youtu.be/jj5E8eb8xRc',3);

INSERT INTO exercises 
VALUES (3006,'RFE Squat','https://youtu.be/4NVyqqCjqjU',3);

INSERT INTO exercises 
VALUES (3007,'Reverse Wall Slide','https://youtu.be/zZs08ZCuKkQ',3);

INSERT INTO tier1 
VALUES(2000,'Deadlift','Hinge & Reach');

INSERT INTO tier2 
VALUES(2001,'DB Standing Press','Rotational Med Ball Throw','TRX Row');

INSERT INTO tier3 
VALUES(2002,'Slideboard Crunch','RFE Squat','Reverse Wall Slide');
