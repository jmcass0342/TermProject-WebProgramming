# TermProject-WebProgramming



<b>Jose Casseres</b>

<b>Available meeting times:</b>

Monday: 7 pm - until needed<br>
Tuesday-Thursday: After 7pm<br>
Wednesday: 3:30pm - 6:00 pm  or 8pm- until needed<br>

Open to meet on Friday's, Saturday's and Sunday's when needed.<br>
