INSERT INTO Users 
VALUES (1,'Test','User', 'test','123abc', 'mail@mail.com', '2', '1',0);

INSERT INTO workout
VALUES(5001,2000,2001,2002);

INSERT INTO hasWorkout
VALUES(7000,1,5001);