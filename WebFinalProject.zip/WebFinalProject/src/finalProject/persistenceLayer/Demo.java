package finalProject.persistenceLayer;


 

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import finalProject.persistenceLayer.DbUtils;
public class Demo {
	
	private Connection conn = null;
	
	
	public Demo() throws SQLException{
		conn = DbUtils.connect();
	}
	
	public ResultSet getUsers(){
	 	String selectMovies = "select * from  Users";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getPrograms(){
	 	String selectMovies = "select * from program";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getHasPrograms(){
	 	String selectMovies = "select * from hasProgram";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getUserLogin(String username, String password){
	 	String selectMovies = "select * from  Users where username = '" + username + "' and password = '" + password + "'";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getTier1(){
	 	String selectMovies = "select * from  tier1";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getTier2(){
	 	String selectMovies = "select * from  tier2";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getTier3(){
	 	String selectMovies = "select * from  tier3";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public ResultSet getWorkout(){
	 	String selectMovies = "select * from  workout";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	

	public ResultSet getExercise(){
	 	String selectMovies = "select * from  exercises";
	 	Statement stmt2 = null;
	 	ResultSet rs = null;
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( selectMovies ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return rs;
	}
	
	
	public int addUser(String firstName, String lastName, String userName, String password, String email, int difficulty, int days){
		//String insertUser = "insert into Users values ( '"+ firstName  + "' , '" + lastName +"' , '" + userName +"' ,  ";
		StringBuilder insertUser = new StringBuilder();
		insertUser.append("insert into Users values ( ");
		insertUser.append("LAST_INSERT_ID(), ");
		insertUser.append("'" + firstName +"', ");
		insertUser.append("'" + lastName +"', ");
		insertUser.append("'" + userName +"', ");
		insertUser.append("'" + password +"', ");
		insertUser.append("'" + email +"', ");
		if(difficulty == 0){
			insertUser.append("NULL, ");
		}else{
			insertUser.append(difficulty +", ");
		}
		if(days == 0){
			insertUser.append("NULL, ");
		}else{
			insertUser.append(days+ ", ");
		}
		insertUser.append("0 )");
		Statement stmt2 = null;
	 	int result = 0;
	 	System.out.println(insertUser.toString());
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
			
		
			
	       if( stmt2.executeUpdate( insertUser.toString() ) == 1) { // statement returned a result
	    	   result = 1;
	       }else{
	    	   result =0;
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	//work here to check if user has a program and a program for this week
	public ResultSet checkUserProgram(int userId){
		ResultSet rs = null;
		Statement stmt2 = null;
		String check = "select programId from hasProgram h, program p where h.userId = " + userId + " and h.programId = p.id and "
				+ "p.startDate <= CURDATE() and p.endDate >= CURDATE()";
		
		try {
			stmt2 = conn.createStatement();
			 // retrieve the persistent objects
	       //
	       if( stmt2.execute( check ) ) { // statement returned a result
	          rs = stmt2.getResultSet();
	        
	       }
	  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return rs;
	}
	
	
	public void disconnect(){
		try{
			conn.close();
		}catch(SQLException e){
			System.out.println("error");
		}
	}
	
}
